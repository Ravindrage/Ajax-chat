<?php
/*
 * @package AJAX_Chat
 * @author Sebastian Tschan
 * @copyright (c) Sebastian Tschan
 * @license Modified MIT License
 * @link   
 */

// List containing the custom channels:
$channels = array();

// Sample channel list:
$channels[0] = 'Public';
$channels[1] = 'Private';
?>