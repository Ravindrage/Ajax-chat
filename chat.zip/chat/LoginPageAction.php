<?php
 ini_set('display_errors', 'On');
    error_reporting(E_ALL);
  ini_set('error_log','files/logs/error_file.log');


require_once "dbClasses.php";

$ini_array = array();
$host = $username = $password = $dbName = "";

//Obtain setting from application.ini
$ini_path = $_SERVER['DOCUMENT_ROOT']."/ini";
$ini_array = parse_ini_file($ini_path."/application.ini");

$host = $ini_array['host'];
$username = $ini_array['username'];
$password = $ini_array['password'];
$dbName = $ini_array['dbName'];



// define variables for posted  and error fields
$email = $pword = $cookie_name = $rememberMe ="";
$emailErr = $pwordErr = $loginErr = "";
$formErr=FALSE;
$rememberMe = 0;
$cookie_name = "usr_email";
$getvals="";

$sessionExists = FALSE;
$userArray = array();
if(session_status() == PHP_SESSION_ACTIVE){
    //do not start session
}
else{
  session_start();
}


    if(isset($_SESSION['userSess'])){
        $sessionExists = TRUE;
        $userArray = $_SESSION['userSess'];
    }
    //echo "Chcking if session exist:".$sessionExists;
require_once "commonFunctions.php";

if($_SERVER["REQUEST_METHOD"] == "GET")
{
    if(isset($_SERVER["HTTP_REFERER"]))
    {
        $returnURL = htmlspecialchars($_SERVER["HTTP_REFERER"]);
    }
    else{
        $returnURL = "dashboard.php";
    }

    if(count($_GET) > 0)
        {
            foreach($_GET as $g=>$val)
            {
                if($g == "tutorID")
                {
                     $getvals = $getvals.$g."=".$val."&";
                }

            }

        }


}

//echo $getvals;
// Validate and obtain posted variables

if ($_SERVER['PHP_SELF'] == $_SERVER['SCRIPT_NAME'] and $_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["getvalues"])) {
    $getvals = "";
  }
   else {
       $getvals = $_POST["getvalues"];
   }

  if (empty($_POST["emailaddr"])) {
    $emailErr = "blank";
    $formErr = TRUE;
  }
   else {
       $email = validate_input($_POST["emailaddr"]);
       if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

         $emailErr = "format";
         $formErr = TRUE;
        }



    }

   if (empty($_POST["pword"])) {
    $pwordErr = "Password is required. Please enter Password.";
    $formErr = TRUE;
  }
   else {
       $pword = validate_input($_POST["pword"]);
   }

   if(isset($_POST["rememberMe"])){
       if($_POST["rememberMe"])
        {
            $rememberMe = 1;
        }
   }


    if(!$formErr)
   {
      //validate if user exists
      $rs_arr = array();
       $rs_arr = ValidateUsr($email,$pword);

       if(count($rs_arr) > 1){

            if($rs_arr['USER_Password']==$pword){

                if($rs_arr['USER_ISActive'] == 1 || $rs_arr['USER_DELETED'] == 1 )
                {
                            // set cookie
                        if($rememberMe == 1){
                            setUsrCookie($email);
                        }

                        //set user logged in date & time and isOnline flag to Yes
                        saveLogininfo($email);
                         //set user session


                        // $_SESSION['name'] = "hello" ;
                      //   print_r($_SESSION);
                        $usrarr= array();
                      //  echo UserLNAME ; exit;

                        $usrarr['ID'] = $rs_arr['User_ID'];
                        $usrarr['FNAME'] = $rs_arr['USER_FName'];
                        $usrarr['LNAME']= $rs_arr['USER_LName'];
                        $usrarr['EMAIL'] = $rs_arr['USER_Email'];
                        $usrarr['TYPE'] = $rs_arr['USER_TYPE'];
                        $usrarr['isActive'] = $rs_arr['USER_ISActive'];
                        $usrarr['BLOCK_CHAT'] = $rs_arr['BLOCK_CHAT'];
                        $usrarr['BAN_CHAT'] = $rs_arr['BAN_CHAT'];
                        $usrarr['isBusy'] = 0;
                        $usrarr['isOnline'] = 1;
                        if($rs_arr['USER_TYPE'] === "Student"){
                            $usrarr['GRD'] = $rs_arr['GRADE'];
                            $usrarr['SUB'] = $rs_arr['SUBJECTS'];
                            $usrarr['CHN'] = $rs_arr['CHANNEL'];
                        }
                        else{
                            $usrarr['GRD'] = $rs_arr['TEACHING_GRADE'];
                            $usrarr['SUB'] = $rs_arr['TEACHING_SUBJECTS'];
                            $usrarr['MTD'] = $rs_arr['TUTOR_CATEGORY_ID'];
                            $usrarr['expPrice'] = $rs_arr['EXP_HRLY_PRICE'];
                            $usrarr['pastExp'] = $rs_arr['PAST_EXP'];
                          /*  $usrarr['profile'] = $rs_arr['PROFILE'];
                            $usrarr['imgpath'] = $rs_arr['IMG_PATH'];*/
                        }

                           //$GLOBALS['user'] = $usrarr;
                           global $arrayuser ;
                          $arrayuser = $usrarr ;


                        if(session_status() == PHP_SESSION_ACTIVE){
                            //do not start session
                        }
                        else{

                        session_start();
                        }
                        $_SESSION['userSess'] = $usrarr;


                        /*if($rs_arr['USER_TYPE'] == "Student"){

                            $loginpageaddr = "http:".DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR.$_SERVER['HTTP_HOST'].DIRECTORY_SEPARATOR."StudentDashboard.php";
                         }
                         else{
                                    $loginpageaddr = "http:".DIRECTORY_SEPARATOR.DIRECTORY_SEPARATOR.$_SERVER['HTTP_HOST'].DIRECTORY_SEPARATOR."TutorDashboard.php";
                         }*/

                        if($getvals != "")
                         {
                             $loginpageaddr = "dashboard.php?".$getvals;
                         }
                         else{
                             $loginpageaddr = "dashboard.php";
                         }
                        //$loginpageaddr = "dashboard.php";
                        //header('Location:'.$loginpageaddr);
                        //used the below as header does not work in iPage server
                //echo "You have logged in";
                        echo "<meta http-equiv=\"refresh\" content=\"0; URL=$loginpageaddr\" />";
                }
                else
                {
                    if($rs_arr['USER_ISActive'] == 0 and $rs_arr['USER_COMMENTS'] == "AWAITING PARENT APPROVAL")
                    {
                        $loginErr = "parent_approval";
                    }
                    elseif($rs_arr['USER_ISActive'] == 0 and $rs_arr['USER_COMMENTS'] == "AWAITING VERIFICATION")
                    {

                        $loginErr = "tutor_confirm";
                    }

                    else
                    {
                        $loginErr = "locked";
                    }

                }

            }
            else{
                //echo "Username or password does not match";
                $loginErr = "match";
            }
           }
            else {$loginErr = "unfound";}


 }
}

function ValidateUsr($emailaddr,$pass)
 {
      $user_result = array();
     //construct SQL
     $sql = "SELECT User_ID, USER_FName, USER_LName,USER_Email,USER_Password,USER_TYPE,USER_ISActive,USER_DELETED,USER_COMMENTS,BLOCK_CHAT,BAN_CHAT FROM TB_User";
     $sql = $sql . " WHERE USER_Email = '$emailaddr';";

     // construct prepared statment for addtional user info
     $sql_student = "SELECT GRADE,SUBJECTS,CHANNEL FROM TB_StudentInfo";
     $sql_student = $sql_student . " WHERE USER_ID = :userID;";

     $sql_tutor = "SELECT TEACHING_GRADE,TEACHING_SUBJECTS,TUTOR_CATEGORY_ID, PROFILE,EXP_HRLY_PRICE,PAST_EXP,IMG_PATH FROM TB_TutorInfo";
     $sql_tutor = $sql_tutor . " WHERE USER_ID = :userID;";

try {
        $myconn = dbConnect();
        $qryResult = $myconn->prepare($sql);
        $qryResult->execute();
        $user_result = $qryResult->fetch(PDO::FETCH_ASSOC);

        $result = array();
        //check if result array has only one record
        if($qryResult->rowcount() == 1){

            if($user_result['USER_TYPE'] == "Student"){
               $qryRes = $myconn->prepare($sql_student);
               $qryRes->bindParam('userID',$user_result['User_ID']);

               $qryRes->execute();
               $result = $qryRes->fetch(PDO::FETCH_ASSOC);

            }
            else{
                $qryRes = $myconn->prepare($sql_tutor);
                $qryRes->bindParam('userID',$user_result['User_ID']);

                $qryRes->execute();
                $result = $qryRes->fetch(PDO::FETCH_ASSOC);
            }

            if(count($result)>0){
               $user_result = array_merge($user_result,$result);
            }

        }
        else{

            $GLOBALS['emailErr'] = "Too many users returned. Contact Administrator.";
        }
    }

catch(PDOException $e)
    {
        echo "Connection failed: " . $e->getMessage();
    }
$myconn = NULL;
return $user_result;
}


 function saveLogininfo($em)
 {
     //construct SQL
     $sql = "UPDATE TB_User SET USER_LastLogged_Date = CURRENT_TIMESTAMP, USER_ISOnline = 1 WHERE USER_Email = '$em';";

//echo $sql;

try {
    $myconn = dbConnect();

    $qryResult = $myconn->prepare($sql);
    $qryResult->execute();


    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
    $myconn = NULL;
 }


?>
