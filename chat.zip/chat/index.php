<?php
/*
 * @package AJAX_Chat
 * @author Sebastian Tschan
 * @author Philip Nicolcev
 * @copyright (c) Sebastian Tschan
 * @license Modified MIT License
 * @link
 */
//header('P3P: CP="CAO PSA OUR"');



   if(isset($_REQUEST['sessionid']) and $_REQUEST['sessionid'])
   { session_id($_REQUEST['sessionid']);   $_REQUEST['sessionid'] ; }
     session_start();

    // print_r($_SESSION);

    if(!isset($_SESSION))
      {  session_start(); }


 require_once "../dbClasses.php";
 $myconn = dbConnect();
 $sql = " SELECT * from setting ";
 $stmt = $myconn->prepare($sql);
 $stmt->execute();
 $allvalue = array( );
 $allvalue =  $stmt->fetch(PDO::FETCH_ASSOC);
  //  print_r($allvalue);
    $title = $allvalue['chat_heading'];
    $guestuser = $allvalue['guest_user'];
    $filterwords = $allvalue['filter_words'];
    global  $title,$guestuser,$filterwords  ;
    $guestuser;



//exit;

// Suppress errors:
error_reporting(0);

//global $arrayuser ;


$arrayuser =  $_SESSION ;
//echo $arrayuser['userSess']['ID']; exit;

//print_r($_SESSION);

if($guestuser=='0' && $arrayuser['userSess']['ID'] == '')
{
  echo "<div style='text-align:center; margin-top:50px;'> Please <a href='http://www.citadeltutors.com/loginSignUp.php?action=register' target='_top'>Register</a> Or  <a href='http://www.citadeltutors.com/loginSignUp.php?action=login' target='_top'> login </a>to Site  </div>";
  exit;
}


//print_r($arrayuser);  // exit;

if($arrayuser['userSess']['BLOCK_CHAT']==1 || $arrayuser['userSess']['BAN_CHAT']==  1)
{
  echo "<div style='text-align:center;''> Please Contact to Site Administrator  </div>";
  exit;
}


// Path to the chat directory:
define('AJAX_CHAT_PATH', dirname($_SERVER['SCRIPT_FILENAME']).'/');

// Include custom libraries and initialization code:
require(AJAX_CHAT_PATH.'lib/custom.php');

// Include Class libraries:
require(AJAX_CHAT_PATH.'lib/classes.php');

// Initialize the chat:
//$ajaxChat = new CustomAJAXChat();
//print_r($arrayuser);
//exit;
$ajaxChat = new CustomAJAXChat($arrayuser);
