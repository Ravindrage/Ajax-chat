<?php

require_once "../dbClasses.php";
$myconn = dbConnect();
$sql = " SELECT * from setting ";
$stmt = $myconn->prepare($sql);
$stmt->execute();
$allvalue = array( );
$allvalue =  $stmt->fetch(PDO::FETCH_ASSOC);
 //  print_r($allvalue);
   $title = $allvalue['chat_heading'];
   $guestuser = $allvalue['guest_user'];
   echo $filterwords = $allvalue['filter_words'];
   
?>
