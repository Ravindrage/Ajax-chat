<?php

ini_set("display_errors", "1");
error_reporting( E_ALL );
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);


$data = array();
// print_r($_FILES);
if(isset($_FILES))
{
    $error = false;
    $files = array();

    $uploaddir = $_SERVER["DOCUMENT_ROOT"].'/chat/uploads/';
    foreach($_FILES as $file)
    {    //if(copy($file['tmp_name'], $uploaddir .basename($file['name'])) )
        if(move_uploaded_file($file['tmp_name'], $uploaddir .basename($file['name'])))
        {  $files[] = '/uploads/' .$file['name'];   }
        else
        { $error = true;     }

    }
    $data = ($error) ? array('error' => 'There was an error uploading your files') : array('files' => $files);
}
else
{
    $data = array('success' => 'Form was submitted', 'formData' => $_POST);
}

echo json_encode($data);

?>
