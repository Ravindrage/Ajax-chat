/*
 * @package AJAX_Chat
 * @author Sebastian Tschan
 * @copyright (c) Sebastian Tschan
 * @license Modified MIT License
 * @link
 */

// Overriding client side functionality:

/*
// Example - Overriding the replaceCustomCommands method:
ajaxChat.replaceCustomCommands = function(text, textParts) {
	return text;
}
 */

/*
 * Citadel Tutors client-side configuration
 */

// Citadel Tutors config parameters:
var ajaxChatConfig = {

	// The channelID of the channel to enter on login (the loginChannelName is used if set to null):
	loginChannelID: null,
	// The channelName of the channel to enter on login (the default channel is used if set to null):
	loginChannelName: null,

	// The time in ms between update calls to retrieve new chat messages:
	timerRate: 2000,

	// The URL to retrieve the XML chat messages (must at least contain one parameter):
	ajaxURL: './?ajax=true',
	// The base URL of the chat directory, used to retrieve media files (images, sound files, etc.):
	baseURL: './',

	// A regular expression for allowed source URL's for media content (e.g. images displayed inline);
	regExpMediaUrl: '^((http)|(https)):\\/\\/',

	// If set to false the chat update is delayed until the event defined in ajaxChat.setStartChatHandler():
	startChatOnLoad: true,

	// Defines the IDs of DOM nodes accessed by the chat:
	domIDs: {
		// The ID of the chat messages list:
		chatList: 'chatList',
		// The ID of the online users list:
		onlineList: 'onlineList',
		// The ID of the message text input field:
		inputField: 'inputField',
		// The ID of the message text length counter:
		messageLengthCounter: 'messageLengthCounter',
		// The ID of the channel selection:
	//	channelSelection: 'channelSelection',
		// The ID of the style selection:
		styleSelection: 'styleSelection',
		// The ID of the emoticons container:
		emoticonsContainer: 'emoticonsContainer',
		// The ID of the color codes container:
		colorCodesContainer: 'colorCodesContainer',
		// The ID of the flash interface container:
		flashInterfaceContainer: 'flashInterfaceContainer',
        // The ID of the status icon:
        statusIcon: 'statusIconContainer'
	},

	// Defines the settings which can be modified by users:
	settings: {
		// Defines if BBCode tags are replaced with the associated HTML code tags:
		bbCode: true,
		// Defines if image BBCode is replaced with the associated image HTML code:
		bbCodeImages: true,
		// Defines if color BBCode is replaced with the associated color HTML code:
		bbCodeColors: true,
		// Defines if hyperlinks are made clickable:
		hyperLinks: true,
		// Defines if line breaks are enabled:
		lineBreaks: true,
		// Defines if emoticon codes are replaced with their associated images:
		emoticons: true,

		// Defines if the focus is automatically set to the input field on chat load or channel switch:
		autoFocus: true,
		// Defines if the chat list scrolls automatically to display the latest messages:
		autoScroll: true,
		// The maximum count of messages displayed in the chat list (will be ignored if set to 0):
		maxMessages: 0,

		// Defines if long words are wrapped to avoid vertical scrolling:
		wordWrap: true,
		// Defines the maximum length before a word gets wrapped:
		maxWordLength: 32,

		// Defines the format of the date and time displayed for each chat message:
		dateFormat: '(%H:%i:%s)',

		// Defines if font colors persist without the need to assign them to each message:
		persistFontColor: false,
		// The default font color, uses the page default font color if set to null:
		fontColor: null,

		// Defines if sounds are played:
		audio: true,
		// Defines the sound volume (0.0 = mute, 1.0 = max):
		audioVolume: 1.0,

		// Defines the sound that is played when normal messages are reveived:
		soundReceive: 'sound_1',
		// Defines the sound that is played on sending normal messages:
		soundSend: 'sound_2',
		// Defines the sound that is played on channel enter or login:
		soundEnter: 'sound_3',
		// Defines the sound that is played on channel leave or logout:
		soundLeave: 'sound_4',
		// Defines the sound that is played on chatBot messages:
		soundChatBot: 'sound_5',
		// Defines the sound that is played on error messages:
		soundError: 'sound_6',
		// Defines the sound that is played when private messages are received:
		soundPrivate: 'sound_7',

		// Defines if the document title blinks on new messages:
		blink: true,
		// Defines the blink interval in ms:
		blinkInterval: 500,
		// Defines the number of blink intervals:
		blinkIntervalNumber: 10
	},

	// Defines a list of settings which are not to be stored in a session cookie:
	nonPersistentSettings: [],

	// Defines the list of allowed BBCodes:
	bbCodeTags:[
		'b',
		'i',
		'u',
		'quote',
		'code',
		'color',
		'url',
		'img'
	],

	// Defines the list of allowed color codes:
	colorCodes: [
		'gray',
		'silver',
		'white',
		'yellow',
		'orange',
		'red',
		'fuchsia',
		'purple',
		'navy',
		'blue',
		'aqua',
		'teal',
		'green',
		'lime',
		'olive',
		'maroon',
		'black'
	],

	// Defines the list of allowed emoticon codes:
	emoticonCodes: [
		':)',
		':(',
		';)',
		':P',
		':D',
		':|',
		':O',
		':?',
		'8)',
		'8o',
		'B)',
		':-)',
		':-(',
		':-*',
		'O:-D',
		'>:-D',
		':o)',
		':idea:',
		':important:',
		':help:',
		':error:',
		':warning:'

 	],

 	// Defines the list of emoticon files associated with the emoticon codes:
	emoticonFiles: [
		'smile.png',
		'sad.png',
		'wink.png',
		'razz.png',
		'grin.png',
		'plain.png',
		'surprise.png',
		'confused.png',
		'glasses.png',
		'eek.png',
		'cool.png',
		'smile-big.png',
		'crying.png',
		'kiss.png',
		'angel.png',
		'devilish.png',
		'monkey.png',
		'idea.png',
		'important.png',
		'help.png',
		'error.png',
		'warning.png'

	],

	// Defines the available sounds loaded on chat start:
	soundFiles: {
		sound_1: 'sound_1.mp3',
		sound_2: 'sound_2.mp3',
		sound_3: 'sound_3.mp3',
		sound_4: 'sound_4.mp3',
		sound_5: 'sound_5.mp3',
		sound_6: 'sound_6.mp3',
		sound_7: 'sound_7.mp3'
	},


	// Once users have been logged in, the following values are overridden by those in config.php.
	// You should set these to be the same as the ones in config.php to avoid confusion.

	// Session identification, used for style and setting cookies:
	sessionName: 'ajax_chat',
	// The time in days until the style and setting cookies expire:
	cookieExpiration: 365,
	// The path of the cookies, '/' allows to read the cookies from all directories:
	cookiePath: '/',
	// The domain of the cookies, defaults to the hostname of the server if set to null:
	cookieDomain: null,
	// If enabled, cookies must be sent over secure (SSL/TLS encrypted) connections:
	cookieSecure: null,
	// The name of the chat bot:
	chatBotName: 'ChatBot',
	// The userID of the chat bot:
	chatBotID: 2147483647,
	// Allow/Disallow registered users to delete their own messages:
	allowUserMessageDelete: true,
	// Minutes until a user is declared inactive (last status update) - the minimum is 2 minutes:
	inactiveTimeout: 2,
	// UserID plus this value are private channels (this is also the max userID and max channelID):
	privateChannelDiff: 500000000,
	// UserID plus this value are used for private messages:
	privateMessageDiff: 1000000000,
	// Defines if login/logout and channel enter/leave are displayed:
	showChannelMessages: true,
	// Max messageText length:
	messageTextMaxLength: 1040,
	// Defines if the socket server is enabled:
	socketServerEnabled: false,
	// Defines the hostname of the socket server used to connect from client side:
	socketServerHost: 'localhost',
	// Defines the port of the socket server:
	socketServerPort: 1935,
	// This ID can be used to distinguish between different chat installations using the same socket server:
	socketServerChatID: 0,

	// Debug allows console logging or alerts on caught errors - false/0 = no debug, true/1/2 = console log, 2 = alerts
	debug: false
};

//var words = document.getElementById('filter_text').value;

//alert(filterwords);

/*$.ajax({ url: "filterwords.php",
				action:"post",
				success: function(result){
				var filterwords = result ;
			  //	alert(filterwords);
		  //	alert("ram");

			/*	ajaxChat.replaceCustomText = function(text) {
				    text=text.replace(/fuck/gi, 'Fruggles');
				    text=text.replace(/foo/gi, 'Donkey Foo');

             	//alert(filterwords);
				    var allwords = filterwords.split(",");
					//	alert(allwords);
						//alert(allwods.length);
						for(i=0;i<allwods.length;i++)
						{
							//alert(allwods[i]);
							text=text.replace(/allwods[i]/gi, 'Foo');
						}
				    return text;
				}

		}});
*/

ajaxChat.replaceCustomText = function(text) {
    text=text.replace(/fuck/gi, '**');
    text=text.replace(/foo/gi, 'Foo');
		text=text.replace(/50 yard cunt punt/gi, '**');
	text=text.replace(/5h1t/gi, '**');
	text=text.replace(/5hit/gi, '**');
	text=text.replace(/a_s_s/gi, '**');
	text=text.replace(/a2m/gi, '**');
	text=text.replace(/a55/gi, '**');
	text=text.replace(/adult/gi, '**');
	text=text.replace(/amateur/gi, '**');
	text=text.replace(/anal/gi, '**');
	text=text.replace(/anal impaler/gi, '**');
	text=text.replace(/anal leakage/gi, '**');
	text=text.replace(/anilingus/gi, '**');
	text=text.replace(/anus/gi, '**');
	text=text.replace(/ar5e/gi, '**');
	text=text.replace(/arrse/gi, '**');
	text=text.replace(/arse/gi, '**');
	text=text.replace(/arsehole/gi, '**');
	text=text.replace(/ass/gi, '**');
	text=text.replace(/ass fuck/gi, '**');
	text=text.replace(/asses/gi, '**');
	text=text.replace(/assfucker/gi, '**');
	text=text.replace(/ass-fucker/gi, '**');
	text=text.replace(/assfukka/gi, '**');
	text=text.replace(/asshole/gi, '**');
	text=text.replace(/asshole/gi, '**');
	text=text.replace(/assholes/gi, '**');
	text=text.replace(/assmucus/gi, '**');
	text=text.replace(/assmunch/gi, '**');
	text=text.replace(/asswhole/gi, '**');
	text=text.replace(/autoerotic/gi, '**');
	text=text.replace(/b!tch/gi, '**');
	text=text.replace(/b00bs/gi, '**');
	text=text.replace(/b17ch/gi, '**');
	text=text.replace(/b1tch/gi, '**');
	text=text.replace(/ballbag/gi, '**');
	text=text.replace(/ballsack/gi, '**');
	text=text.replace(/bang (one's) box/gi, '**');
	text=text.replace(/bangbros/gi, '**');
	text=text.replace(/bareback/gi, '**');
	text=text.replace(/bastard/gi, '**');
	text=text.replace(/beastial/gi, '**');
	text=text.replace(/beastiality/gi, '**');
	text=text.replace(/beef curtain/gi, '**');
	text=text.replace(/bellend/gi, '**');
	text=text.replace(/bestial/gi, '**');
	text=text.replace(/bestiality/gi, '**');
	text=text.replace(/bi+ch/gi, '**');
	text=text.replace(/biatch/gi, '**');
	text=text.replace(/bimbos/gi, '**');
	text=text.replace(/birdlock/gi, '**');
	text=text.replace(/bitch/gi, '**');
	text=text.replace(/bitch tit/gi, '**');
	text=text.replace(/bitcher/gi, '**');
	text=text.replace(/bitchers/gi, '**');
	text=text.replace(/bitches/gi, '**');
	text=text.replace(/bitchin/gi, '**');
	text=text.replace(/bitching/gi, '**');
	text=text.replace(/bloody/gi, '**');
	text=text.replace(/blow job/gi, '**');
	text=text.replace(/blow me/gi, '**');
	text=text.replace(/blow mud/gi, '**');
	text=text.replace(/blowjob/gi, '**');
	text=text.replace(/blowjobs/gi, '**');
	text=text.replace(/blue waffle/gi, '**');
	text=text.replace(/blumpkin/gi, '**');
	text=text.replace(/boiolas/gi, '**');
	text=text.replace(/bollock/gi, '**');
	text=text.replace(/bollok/gi, '**');
	text=text.replace(/boner/gi, '**');
	text=text.replace(/boob/gi, '**');
	text=text.replace(/boobs/gi, '**');
	text=text.replace(/booobs/gi, '**');
	text=text.replace(/boooobs/gi, '**');
	text=text.replace(/booooobs/gi, '**');
	text=text.replace(/booooooobs/gi, '**');
	text=text.replace(/breasts/gi, '**');
	text=text.replace(/buceta/gi, '**');
	text=text.replace(/bugger/gi, '**');
	text=text.replace(/bum/gi, '**');
	text=text.replace(/bunny fucker/gi, '**');
	text=text.replace(/bust a load/gi, '**');
	text=text.replace(/busty/gi, '**');
	text=text.replace(/butt/gi, '**');
	text=text.replace(/butt fuck/gi, '**');
	text=text.replace(/butthole/gi, '**');
	text=text.replace(/buttmuch/gi, '**');
	text=text.replace(/buttplug/gi, '**');
	text=text.replace(/c0ck/gi, '**');
	text=text.replace(/c0cksucker/gi, '**');
	text=text.replace(/carpet muncher/gi, '**');
	text=text.replace(/carpetmuncher/gi, '**');
	text=text.replace(/cawk/gi, '**');
	text=text.replace(/chink/gi, '**');
	text=text.replace(/choade/gi, '**');
	text=text.replace(/chota bags/gi, '**');
	text=text.replace(/cipa/gi, '**');
	text=text.replace(/cl1t/gi, '**');
	text=text.replace(/clit/gi, '**');
	text=text.replace(/clit licker/gi, '**');
	text=text.replace(/clitoris/gi, '**');
	text=text.replace(/clits/gi, '**');
	text=text.replace(/clitty litter/gi, '**');
	text=text.replace(/clusterfuck/gi, '**');
	text=text.replace(/cnut/gi, '**');
	text=text.replace(/cock/gi, '**');
	text=text.replace(/cock pocket/gi, '**');
	text=text.replace(/cock snot/gi, '**');
	text=text.replace(/cockface/gi, '**');
	text=text.replace(/cockhead/gi, '**');
	text=text.replace(/cockmunch/gi, '**');
	text=text.replace(/cockmuncher/gi, '**');
	text=text.replace(/cocks/gi, '**');
	text=text.replace(/cocksuck /gi, '**');
	text=text.replace(/cocksucked /gi, '**');
	text=text.replace(/cocksucker/gi, '**');
	text=text.replace(/cock-sucker/gi, '**');
	text=text.replace(/cocksucking/gi, '**');
	text=text.replace(/cocksucks /gi, '**');
	text=text.replace(/cocksuka/gi, '**');
	text=text.replace(/cocksukka/gi, '**');
	text=text.replace(/cok/gi, '**');
	text=text.replace(/cokmuncher/gi, '**');
	text=text.replace(/coksucka/gi, '**');
	text=text.replace(/coon/gi, '**');
	text=text.replace(/cop some wood/gi, '**');
	text=text.replace(/cornhole/gi, '**');
	text=text.replace(/corp whore/gi, '**');
	text=text.replace(/cox/gi, '**');
	text=text.replace(/cum/gi, '**');
	text=text.replace(/cum chugger/gi, '**');
	text=text.replace(/cum dumpster/gi, '**');
	text=text.replace(/cum freak/gi, '**');
	text=text.replace(/cum guzzler/gi, '**');
	text=text.replace(/cumdump/gi, '**');
	text=text.replace(/cummer/gi, '**');
	text=text.replace(/cumming/gi, '**');
	text=text.replace(/cums/gi, '**');
	text=text.replace(/cumshot/gi, '**');
	text=text.replace(/cunilingus/gi, '**');
	text=text.replace(/cunillingus/gi, '**');
	text=text.replace(/cunnilingus/gi, '**');
	text=text.replace(/cunt/gi, '**');
	text=text.replace(/cunt hair/gi, '**');
	text=text.replace(/cuntbag/gi, '**');
	text=text.replace(/cuntlick /gi, '**');
	text=text.replace(/cuntlicker /gi, '**');
	text=text.replace(/cuntlicking /gi, '**');
	text=text.replace(/cunts/gi, '**');
	text=text.replace(/cuntsicle/gi, '**');
	text=text.replace(/cunt-struck/gi, '**');
	text=text.replace(/cut rope/gi, '**');
	text=text.replace(/cyalis/gi, '**');
	text=text.replace(/cyberfuc/gi, '**');
	text=text.replace(/cyberfuck /gi, '**');
	text=text.replace(/cyberfucked /gi, '**');
	text=text.replace(/cyberfucker/gi, '**');
	text=text.replace(/cyberfuckers/gi, '**');
	text=text.replace(/cyberfucking /gi, '**');
	text=text.replace(/d1ck/gi, '**');
	text=text.replace(/damn/gi, '**');
	text=text.replace(/dick/gi, '**');
	text=text.replace(/dick hole/gi, '**');
	text=text.replace(/dick shy/gi, '**');
	text=text.replace(/dickhead/gi, '**');
	text=text.replace(/dildo/gi, '**');
	text=text.replace(/dildos/gi, '**');
	text=text.replace(/dink/gi, '**');
	text=text.replace(/dinks/gi, '**');
	text=text.replace(/dirsa/gi, '**');
	text=text.replace(/dirty Sanchez/gi, '**');
	text=text.replace(/dlck/gi, '**');
	text=text.replace(/dog-fucker/gi, '**');
	text=text.replace(/doggie style/gi, '**');
	text=text.replace(/doggiestyle/gi, '**');
	text=text.replace(/doggin/gi, '**');
	text=text.replace(/dogging/gi, '**');
	text=text.replace(/donkeyribber/gi, '**');
	text=text.replace(/doosh/gi, '**');
	text=text.replace(/duche/gi, '**');
	text=text.replace(/dyke/gi, '**');
	text=text.replace(/eat a dick/gi, '**');
	text=text.replace(/eat hair pie/gi, '**');
	text=text.replace(/ejaculate/gi, '**');
	text=text.replace(/ejaculated/gi, '**');
	text=text.replace(/ejaculates /gi, '**');
	text=text.replace(/ejaculating /gi, '**');
	text=text.replace(/ejaculatings/gi, '**');
	text=text.replace(/ejaculation/gi, '**');
	text=text.replace(/ejakulate/gi, '**');
	text=text.replace(/erotic/gi, '**');
	text=text.replace(/f u c k/gi, '**');
	text=text.replace(/f u c k e r/gi, '**');
	text=text.replace(/f_u_c_k/gi, '**');
	text=text.replace(/f4nny/gi, '**');
	text=text.replace(/facial/gi, '**');
	text=text.replace(/fag/gi, '**');
	text=text.replace(/fagging/gi, '**');
	text=text.replace(/faggitt/gi, '**');
	text=text.replace(/faggot/gi, '**');
	text=text.replace(/faggs/gi, '**');
	text=text.replace(/fagot/gi, '**');
	text=text.replace(/fagots/gi, '**');
	text=text.replace(/fags/gi, '**');
	text=text.replace(/fanny/gi, '**');
	text=text.replace(/fannyflaps/gi, '**');
	text=text.replace(/fannyfucker/gi, '**');
	text=text.replace(/fanyy/gi, '**');
	text=text.replace(/fatass/gi, '**');
	text=text.replace(/fcuk/gi, '**');
	text=text.replace(/fcuker/gi, '**');
	text=text.replace(/fcuking/gi, '**');
	text=text.replace(/feck/gi, '**');
	text=text.replace(/fecker/gi, '**');
	text=text.replace(/felching/gi, '**');
	text=text.replace(/fellate/gi, '**');
	text=text.replace(/fellatio/gi, '**');
	text=text.replace(/fingerfuck /gi, '**');
	text=text.replace(/fingerfucked /gi, '**');
	text=text.replace(/fingerfucker /gi, '**');
	text=text.replace(/fingerfuckers/gi, '**');
	text=text.replace(/fingerfucking /gi, '**');
	text=text.replace(/fingerfucks /gi, '**');
	text=text.replace(/fist fuck/gi, '**');
	text=text.replace(/fistfuck/gi, '**');
	text=text.replace(/fistfucked /gi, '**');
	text=text.replace(/fistfucker /gi, '**');
	text=text.replace(/fistfuckers /gi, '**');
	text=text.replace(/fistfucking /gi, '**');
	text=text.replace(/fistfuckings /gi, '**');
	text=text.replace(/fistfucks /gi, '**');
	text=text.replace(/flange/gi, '**');
	text=text.replace(/flog the log/gi, '**');
	text=text.replace(/fook/gi, '**');
	text=text.replace(/fooker/gi, '**');
	text=text.replace(/fuck hole/gi, '**');
	text=text.replace(/fuck puppet/gi, '**');
	text=text.replace(/fuck trophy/gi, '**');
	text=text.replace(/fuck yo mama/gi, '**');
	text=text.replace(/fuck/gi, '**');
	text=text.replace(/fucka/gi, '**');
	text=text.replace(/fuck-ass/gi, '**');
	text=text.replace(/fuck-bitch/gi, '**');
	text=text.replace(/fucked/gi, '**');
	text=text.replace(/fucker/gi, '**');
	text=text.replace(/fuckers/gi, '**');
	text=text.replace(/fuckhead/gi, '**');
	text=text.replace(/fuckheads/gi, '**');
	text=text.replace(/fuckin/gi, '**');
	text=text.replace(/fucking/gi, '**');
	text=text.replace(/fuckings/gi, '**');
	text=text.replace(/fuckingshitmotherfucker/gi, '**');
	text=text.replace(/fuckme /gi, '**');
	text=text.replace(/fuckmeat/gi, '**');
	text=text.replace(/fucks/gi, '**');
	text=text.replace(/fucktoy/gi, '**');
	text=text.replace(/fuckwhit/gi, '**');
	text=text.replace(/fuckwit/gi, '**');
	text=text.replace(/fudge packer/gi, '**');
	text=text.replace(/fudgepacker/gi, '**');
	text=text.replace(/fuk/gi, '**');
	text=text.replace(/fuker/gi, '**');
	text=text.replace(/fukker/gi, '**');
	text=text.replace(/fukkin/gi, '**');
	text=text.replace(/fuks/gi, '**');
	text=text.replace(/fukwhit/gi, '**');
	text=text.replace(/fukwit/gi, '**');
	text=text.replace(/fux/gi, '**');
	text=text.replace(/fux0r/gi, '**');
	text=text.replace(/gangbang/gi, '**');
	text=text.replace(/gangbang/gi, '**');
	text=text.replace(/gang-bang/gi, '**');
	text=text.replace(/gangbanged /gi, '**');
	text=text.replace(/gangbangs /gi, '**');
	text=text.replace(/gassy ass/gi, '**');
	text=text.replace(/gaylord/gi, '**');
	text=text.replace(/gaysex/gi, '**');
	text=text.replace(/goatse/gi, '**');
	text=text.replace(/god/gi, '**');
	text=text.replace(/god damn/gi, '**');
	text=text.replace(/god-dam/gi, '**');
	text=text.replace(/goddamn/gi, '**');
	text=text.replace(/goddamned/gi, '**');
	text=text.replace(/god-damned/gi, '**');
	text=text.replace(/ham flap/gi, '**');
	text=text.replace(/hardcoresex /gi, '**');
	text=text.replace(/hell/gi, '**');
	text=text.replace(/heshe/gi, '**');
	text=text.replace(/hoar/gi, '**');
	text=text.replace(/hoare/gi, '**');
	text=text.replace(/hoer/gi, '**');
	text=text.replace(/homo/gi, '**');
	text=text.replace(/homoerotic/gi, '**');
	text=text.replace(/hore/gi, '**');
	text=text.replace(/horniest/gi, '**');
	text=text.replace(/horny/gi, '**');
	text=text.replace(/hotsex/gi, '**');
	text=text.replace(/how to kill/gi, '**');
	text=text.replace(/how to murdep/gi, '**');
	text=text.replace(/jackoff/gi, '**');
	text=text.replace(/jack-off /gi, '**');
	text=text.replace(/jap/gi, '**');
	text=text.replace(/jerk/gi, '**');
	text=text.replace(/jerk-off /gi, '**');
	text=text.replace(/jism/gi, '**');
	text=text.replace(/jiz /gi, '**');
	text=text.replace(/jizm /gi, '**');
	text=text.replace(/jizz/gi, '**');
	text=text.replace(/kawk/gi, '**');
	text=text.replace(/kinky Jesus/gi, '**');
	text=text.replace(/knob/gi, '**');
	text=text.replace(/knob end/gi, '**');
	text=text.replace(/knobead/gi, '**');
	text=text.replace(/knobed/gi, '**');
	text=text.replace(/knobend/gi, '**');
	text=text.replace(/knobend/gi, '**');
	text=text.replace(/knobhead/gi, '**');
	text=text.replace(/knobjocky/gi, '**');
	text=text.replace(/knobjokey/gi, '**');
	text=text.replace(/kock/gi, '**');
	text=text.replace(/kondum/gi, '**');
	text=text.replace(/kondums/gi, '**');
	text=text.replace(/kum/gi, '**');
	text=text.replace(/kummer/gi, '**');
	text=text.replace(/kumming/gi, '**');
	text=text.replace(/kums/gi, '**');
	text=text.replace(/kunilingus/gi, '**');
	text=text.replace(/kwif/gi, '**');
	text=text.replace(/l3i+ch/gi, '**');
	text=text.replace(/l3itch/gi, '**');
	text=text.replace(/labia/gi, '**');
	text=text.replace(/LEN/gi, '**');
	text=text.replace(/lmao/gi, '**');
	text=text.replace(/lmfao/gi, '**');
	text=text.replace(/lmfao/gi, '**');
	text=text.replace(/lust/gi, '**');
	text=text.replace(/lusting/gi, '**');
	text=text.replace(/m0f0/gi, '**');
	text=text.replace(/m0fo/gi, '**');
	text=text.replace(/m45terbate/gi, '**');
	text=text.replace(/ma5terb8/gi, '**');
	text=text.replace(/ma5terbate/gi, '**');
	text=text.replace(/mafugly/gi, '**');
	text=text.replace(/masochist/gi, '**');
	text=text.replace(/masterb8/gi, '**');
	text=text.replace(/masterbat*/gi, '**');
	text=text.replace(/masterbat3/gi, '**');
	text=text.replace(/masterbate/gi, '**');
	text=text.replace(/master-bate/gi, '**');
	text=text.replace(/masterbation/gi, '**');
	text=text.replace(/masterbations/gi, '**');
	text=text.replace(/masturbate/gi, '**');
				return text;
}
